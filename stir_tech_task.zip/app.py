# Required Libraries
import time
import json
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from pymongo import MongoClient
from proxymesh import ProxyMesh
from datetime import datetime

# MongoDB Setup
client = MongoClient('mongodb://localhost:27017/')  # Adjust MongoDB connection
mongo_db = client['stir_tech']
mongo_collection = mongo_db['trending_topics']

# Selenium Setup
service = Service('path/to/chromedriver')  # Update the path to chromedriver
options = webdriver.ChromeOptions()
options.add_argument('--proxy-server=proxymesh_ip:port')  # Update ProxyMesh credentials

# Fetch Trending Topics
def fetch_trending_topics():
    driver = webdriver.Chrome(service=service, options=options)
    driver.get('https://twitter.com/login')

    # Log in to Twitter (replace with your credentials)
    username = driver.find_element(By.NAME, 'session[username_or_email]')
    password = driver.find_element(By.NAME, 'session[password]')

    username.send_keys('your_twitter_username')
    password.send_keys('your_twitter_password')
    password.send_keys(Keys.RETURN)

    time.sleep(5)  # Wait for the page to load

    # Extract Trending Topics
    trending_topics = []
    try:
        trends_section = driver.find_element(By.XPATH, '//*[contains(@aria-label, "Timeline: Trending now")]')
        trends = trends_section.find_elements(By.CSS_SELECTOR, 'div[dir="ltr"] span')
        
        for trend in trends[:5]:  # Fetch top 5 trends
            trending_topics.append(trend.text)
    except Exception as e:
        print("Error fetching trends:", e)

    # Capture Details
    unique_id = str(mongo_collection.estimated_document_count() + 1)
    ip_address = ProxyMesh.get_current_ip()  # Assume ProxyMesh has this function
    timestamp = datetime.now()

    record = {
        '_id': unique_id,
        'trend1': trending_topics[0] if len(trending_topics) > 0 else "",
        'trend2': trending_topics[1] if len(trending_topics) > 1 else "",
        'trend3': trending_topics[2] if len(trending_topics) > 2 else "",
        'trend4': trending_topics[3] if len(trending_topics) > 3 else "",
        'trend5': trending_topics[4] if len(trending_topics) > 4 else "",
        'date_time': timestamp,
        'ip_address': ip_address
    }

    # Store in MongoDB
    mongo_collection.insert_one(record)

    driver.quit()
    return record

# Flask Webpage
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return "<html><body><a href='/run_script'>Click here to run the script</a></body></html>"

@app.route('/run_script', methods=['GET'])
def run_script():
    record = fetch_trending_topics()
    result_html = f"<html><body><h2>These are the most happening topics as on {record['date_time']}</h2>"
    result_html += f"<ul><li>{record['trend1']}</li><li>{record['trend2']}</li><li>{record['trend3']}</li><li>{record['trend4']}</li><li>{record['trend5']}</li></ul>"
    result_html += f"<p>The IP address used for this query was {record['ip_address']}.</p>"
    result_html += f"<p>Here's a JSON extract of this record from the MongoDB:</p><pre>{json.dumps(record, indent=2)}</pre>"
    result_html += "<a href='/'>Click here to run the query again.</a></body></html>"
    return result_html

if __name__ == "__main__":
    app.run(debug=True)
